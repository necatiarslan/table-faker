from . import config
from . import util
from .plugin_loader import PluginManager
import pandas as pd
import numpy as np
from faker import Faker
import random
from os import path
from datetime import date, datetime, timedelta, time, timezone, tzinfo, UTC, MINYEAR, MAXYEAR
import importlib
import importlib.util
import sys, math, gc, psutil, string
import hashlib
import ast

class TableFaker:
    def __init__(self):
        self.reset_start_time()
        self.primary_key_cache = {}
        self.primary_key_seed = None
        self.parent_rows = {}          # table -> {pk_value: full_row_dict}
        self.fake_by_locale = {}       # locale -> Faker
        self._current_row = None       # for copy_from_fk access during phase B
        self.generated_rows = {}       # table_name -> list of row dicts (for get_table)
        self.unique_fk_used = {}       # (child_table, parent_table, parent_column) -> set of used PK values
        self._current_child_table = None  # set during generate_table for is_unique tracking
    
    def reset_start_time(self):
        self.start_time = datetime.now()
    
    def _apply_seed(self, seed):
        """Apply seed to random, numpy, and Faker for determinism."""
        if seed is None:
            return
        random.seed(seed)
        np.random.seed(seed)
        Faker.seed(seed)
    
    def _get_fake(self, locale):
        """Get or create cached Faker instance for a locale."""
        if locale not in self.fake_by_locale:
            self.fake_by_locale[locale] = Faker(locale)
        return self.fake_by_locale[locale]
    
    def _stable_seed(self, *parts):
        """Generate deterministic seed from parts using MD5."""
        key = "|".join(map(str, parts)).encode("utf-8")
        return int.from_bytes(hashlib.md5(key).digest()[:4], "little")
    
    def _copy_from_fk(self, parent_table, fk_col, parent_attr):
        """Copy attribute from parent row via foreign key.

        New parameter order: (parent_table, fk_col, parent_attr)
        """
        fk_val = self._current_row[fk_col]
        try:
            return self.parent_rows[parent_table][fk_val][parent_attr]
        except KeyError:
            raise RuntimeError(f"Missing parent row for {parent_table}.{parent_attr} with key={fk_val}")

    def print_sys_stats(self):
        end_time = datetime.now()
        elapsed_time = end_time - self.start_time
        minutes, seconds = divmod(elapsed_time.seconds, 60)
        seconds = f"{seconds:02}"
        milliseconds = f"{elapsed_time.microseconds // 1000:03}"

        memory_usage = psutil.Process().memory_info().rss / (1024 * 1024)
        memory_usage = f"{memory_usage:.2f} MB"

        cpu_usage = psutil.cpu_percent(interval=1)  # Measure over 1 second
        cpu_usage = f"{cpu_usage:.2f}%"

        util.log(f"Elapsed:{minutes}:{seconds}:{milliseconds}, Memory:{memory_usage}, CPU:{cpu_usage}", util.FOREGROUND_COLOR.GREEN)

    def to_target(self, file_type, config_source, target_file_path, table_name=None, seed=None, infer_attrs=None, **kwargs) :
        if target_file_path is None:
            target_file_path = "."
        
        if file_type not in ["csv", "json", "excel", "parquet", "deltalake", "sql"]:
            raise Exception(f"Wrong file_type = {file_type}")
        
        result = {}
        configurator = config.Config(config_source)
        
        # Use CLI-provided seed if available, otherwise use config seed
        if seed is None:
            seed = configurator.config.get("config", {}).get("seed")
        self._apply_seed(seed)
        
        # Override infer_entity_attrs_by_name if provided via CLI
        if infer_attrs is not None:
            # Convert string 'true'/'false' to boolean
            infer_bool = infer_attrs.lower() == 'true' if isinstance(infer_attrs, str) else infer_attrs
            if "config" not in configurator.config:
                configurator.config["config"] = {}
            configurator.config["config"]["infer_entity_attrs_by_name"] = infer_bool
        
        tables = configurator.config["tables"]
        
        for table in tables:
            if table_name is not None and table["table_name"] != table_name:
                continue #skip other tables

            row_count = table['row_count'] if "row_count" in table else 10
            export_file_count = table["export_file_count"] if "export_file_count" in table else 1
            export_file_row_count = table["export_file_row_count"] if "export_file_row_count" in table else sys.maxsize
            if export_file_count > 1:
                export_file_row_count = math.ceil(row_count / export_file_count)
            

            if path.isdir(target_file_path) or file_type == "deltalake":

                if file_type == "deltalake" and table["table_name"] == table_name and not path.exists(target_file_path) and path.exists(path.dirname(path.normpath(target_file_path)) + "/"):
                    # in delta lake format, if the latest folder does not exists, assume it is requested delta lake folder
                    temp_file_path = target_file_path.rstrip('/')
                    export_base_name = None
                else:
                    custom_export_name = table.get("export_file_name")
                    export_base_name = custom_export_name or table["table_name"]
                    if custom_export_name:
                        file_name = export_base_name + util.get_file_extension(file_type)
                    else:
                        file_name = util.get_temp_filename(export_base_name) + util.get_file_extension(file_type)
                    temp_file_path = path.join(target_file_path, file_name)

                self.to_target_file(file_type, temp_file_path, table_name, kwargs, result, configurator, table, export_file_row_count, row_count, export_base_name)
                result[table_name] = temp_file_path
            else:
                export_base_name = table.get("export_file_name") or table["table_name"]
                self.to_target_file(file_type, target_file_path, table_name, kwargs, result, configurator, table, export_file_row_count, row_count, export_base_name)
                break # if single table is requested
        
        return result

    def to_pandas(self, config_source:str, table_name=None, **kwargs):
        result = {}
        configurator = config.Config(config_source)
        seed = configurator.config.get("config", {}).get("seed")
        self._apply_seed(seed)
        tables = configurator.config["tables"]
        for table in tables:
            if table_name is not None and table["table_name"] != table_name:
                continue #skip other tables
            self.reset_start_time()
            df = self.generate_table(table, configurator, **kwargs)
            self.print_sys_stats()
            result[table["table_name"]] = df
        return result

    def to_target_file(self, file_type, target_file_path, table_name, kwargs, result, configurator, table, export_file_row_count, row_count, export_base_name=None):
        internal_row_id = 0
        internal_row_count = min(export_file_row_count, sys.maxsize)
        file_count = math.ceil(row_count / export_file_row_count)
        total_exported_row_count = 0
        for i in range(file_count):
                    #internal_row_count = export_file_row_count
            internal_row_count = min(export_file_row_count, row_count - total_exported_row_count)
            self.reset_start_time()
            df = self.generate_table(table, configurator, internal_row_id, internal_row_count, **kwargs)
            if file_count > 1:
                file_extension = util.get_file_extension(file_type)
                target_dir = path.dirname(target_file_path)
                temp_file_path = path.join(target_dir, export_base_name + "_" + str(i+1) + file_extension)
            else:
                temp_file_path = target_file_path
            self.call_export_function(df, file_type, temp_file_path)
            del df
            gc.collect()
            util.log(f"data is exported to {temp_file_path}", util.FOREGROUND_COLOR.GREEN)
            self.print_sys_stats()
            result[table_name] = temp_file_path
            internal_row_id = internal_row_id + internal_row_count
            total_exported_row_count = total_exported_row_count + internal_row_count

    def call_export_function(self, data_frame: pd.DataFrame, file_type, target_file_path):
        if file_type == "csv":
            data_frame.to_csv(target_file_path, index=False)
        elif file_type == "json":
            data_frame.to_json(target_file_path, index=False, indent=4, orient='records', date_format='iso')
        elif file_type == "excel":
            data_frame.to_excel(target_file_path, index=False)
        elif file_type == "parquet":
            self._to_parquet_internal(data_frame, target_file_path)
        elif file_type == "sql":
            self.to_sql_internal(data_frame, target_file_path)
        elif file_type == "deltalake":
            self.to_deltalake_internal(data_frame, target_file_path)
        else:
            raise Exception(f"Wrong file_type = {file_type}")

    def _to_parquet_internal(self, data_frame: pd.DataFrame, target_file_path):
        import pyarrow as pa
        import pyarrow.parquet as pq
        table = pa.Table.from_pandas(data_frame, preserve_index=False)
        parquet_schema_map = data_frame.attrs.get('parquet_schema')
        if parquet_schema_map:
            pa_schema = self._build_parquet_schema(data_frame, parquet_schema_map)
            table = table.cast(pa_schema, safe=False)
        pq.write_table(table, target_file_path)

    def _build_parquet_schema(self, data_frame: pd.DataFrame, schema_map: dict):
        import pyarrow as pa
        inferred = pa.Schema.from_pandas(data_frame, preserve_index=False)
        fields = []
        for i in range(len(inferred)):
            field = inferred.field(i)
            if field.name in schema_map:
                new_type = self._parse_parquet_type(schema_map[field.name])
                fields.append(pa.field(field.name, new_type, nullable=field.nullable))
            else:
                fields.append(field)
        return pa.schema(fields)

    @staticmethod
    def _parse_parquet_type(type_str: str):
        import pyarrow as pa
        import re
        type_str = type_str.strip()
        simple = {
            "int8": pa.int8(),
            "int16": pa.int16(),
            "int32": pa.int32(),
            "int64": pa.int64(),
            "uint8": pa.uint8(),
            "uint16": pa.uint16(),
            "uint32": pa.uint32(),
            "uint64": pa.uint64(),
            "float16": pa.float16(),
            "float32": pa.float32(),
            "float64": pa.float64(),
            "double": pa.float64(),
            "string": pa.string(),
            "utf8": pa.string(),
            "large_string": pa.large_string(),
            "large_utf8": pa.large_string(),
            "binary": pa.binary(),
            "large_binary": pa.large_binary(),
            "bool": pa.bool_(),
            "boolean": pa.bool_(),
            "date32": pa.date32(),
            "date64": pa.date64(),
            "time32[s]": pa.time32("s"),
            "time32[ms]": pa.time32("ms"),
            "time64[us]": pa.time64("us"),
            "time64[ns]": pa.time64("ns"),
            "timestamp[s]": pa.timestamp("s"),
            "timestamp[ms]": pa.timestamp("ms"),
            "timestamp[us]": pa.timestamp("us"),
            "timestamp[ns]": pa.timestamp("ns"),
        }
        if type_str in simple:
            return simple[type_str]
        m = re.fullmatch(r"decimal128\(\s*(\d+)\s*,\s*(\d+)\s*\)", type_str)
        if m:
            return pa.decimal128(int(m.group(1)), int(m.group(2)))
        raise Exception(f"Unknown parquet_type '{type_str}'. Supported types: {list(simple.keys())} and decimal128(precision, scale)")

    def to_deltalake_internal(self, data_frame: pd.DataFrame, target_file_path):
        if importlib.util.find_spec("deltalake"):
            deltalake = __import__("deltalake")
            deltalake.writer.write_deltalake(target_file_path, data_frame, mode="overwrite")
        else:
            raise Exception("deltalake package is not installed. install it with pip install deltalake")

    def to_sql_internal(self, data_frame: pd.DataFrame, target_file_path):

        table_name = data_frame.Name
        # Keep identifier formatting as provided by config for DB-dialect compatibility.
        insert_script = f'INSERT INTO {table_name}\n({", ".join(data_frame.columns)})\nVALUES\n'

        # Iterate over DataFrame rows and create insert statements
        for _, row in data_frame.iterrows():
            value_list = []
            for value in row:
                if value is None:
                    value_list.append("NULL")
                elif isinstance(value, (str, date, datetime)):
                    escaped = str(value).replace("'", "''")
                    value_list.append(f"'{escaped}'")
                else:
                    value_list.append(str(value))

            values = ', '.join(value_list)
            insert_script += f"({values}),\n"

        # Remove the trailing comma and newline
        insert_script = insert_script.rstrip(',\n')

        # Write the insert script to the target file
        with open(target_file_path, 'w') as file:
            file.write(insert_script + ';')

    def generate_table(self,table, configurator, internal_start_row_id=0, internal_row_count=sys.maxsize, **kwargs) -> pd.DataFrame:
        locale = None
        if "config" in configurator.config and "locale" in configurator.config["config"]:
            locale = configurator.config["config"]["locale"]

        fake = self._get_fake(locale)
        python_import = configurator.get_python_import()
        
        # Load plugins from python_import configuration
        plugins = PluginManager(
            python_import,
            extra_paths=[path.dirname(configurator.file_path)] if configurator.file_path else []
        )
        
        # Add community providers from config
        community_providers = configurator.get_community_providers()
        for module_name, class_name in community_providers:
            try:
                module = importlib.import_module(module_name)
                provider_class = getattr(module, class_name)
                fake.add_provider(provider_class)
            except (ImportError, AttributeError) as e:
                raise RuntimeError(f"Failed to load community provider {module_name}.{class_name}: {e}")
        
        # Add providers passed via kwargs (for programmatic use)
        if "fake_provider" in kwargs:
            if not isinstance(kwargs["fake_provider"], list):
                fake.add_provider(kwargs["fake_provider"])
            else:
                for provider in kwargs["fake_provider"]:
                    fake.add_provider(provider)

        # Base evaluation environment
        base_locals = {
            "random": random,
            "datetime": datetime,
            "date": date,
            "timedelta": timedelta,
            "time": time,
            "timezone": timezone,
            "tzinfo": tzinfo,
            "UTC": UTC,
            "MINYEAR": MINYEAR,
            "MAXYEAR": MAXYEAR,
            "math": math,
            "string": string,
            "fake": fake,
            "result": [],
            "foreign_key": self.foreign_key,
            "copy_from_fk": self._copy_from_fk
        }
        
        # Helper function for plugins to access generated table data
        def get_table(name: str):
            """Get list of generated rows for a table."""
            return self.generated_rows.get(name, [])
        
        # Inject plugins into evaluation environment
        variables = plugins.make_eval_locals(base_locals, get_table)

        # Support for programmatically added custom functions (via kwargs)
        if "custom_function" in kwargs:
            if isinstance(kwargs["custom_function"], list):
                for func in kwargs["custom_function"]:
                    variables[func.__name__] = func
            else:
                func = kwargs["custom_function"]
                variables[func.__name__] = func

        table_name = table['table_name']
        row_count = table['row_count'] if "row_count" in table else 10
        row_count = min(row_count, internal_row_count)
        start_row_id = table['start_row_id'] if "start_row_id" in table else 1
        start_row_id = start_row_id + internal_start_row_id
        columns = table['columns']
 
        # PK null_percentage guard: primary key columns must not specify null_percentage
        for col in columns:
            if col.get("is_primary_key") and "null_percentage" in col:
                raise Exception(f"Primary key column {col['column_name']} cannot have null_percentage")
 
        # Optional name-based inference for copy_from_fk
        infer = configurator.config.get("config", {}).get("infer_entity_attrs_by_name", False)
        if infer:
            col_names = {c["column_name"] for c in columns}
            fk_sources = {}  # "customer_id" -> ("customers","id")
            for c in columns:
                cmd = str(c["data"])
                if 'foreign_key(' in cmd:
                    # Parse foreign_key call to extract table and column safely
                    try:
                        idx = cmd.find('foreign_key(')
                        end_idx = cmd.find(')', idx)
                        if end_idx != -1:
                            # Extract the arguments from foreign_key("table", "column")
                            args_str = cmd[idx+len('foreign_key('):end_idx]
                            # Evaluate as a tuple: ("table", "column") - use literal_eval for safety
                            fk_sources[c["column_name"]] = ast.literal_eval(f"({args_str})")
                    except:
                        pass  # Skip if parsing fails
 
            for c in columns:
                if c.get("data") in (None, "auto"):
                    name = c["column_name"]
                    if "_" in name:
                        prefix, attr = name.split("_", 1)
                        fk_col = f"{prefix}_id"
                        if fk_col in fk_sources:
                            parent_table, _ = fk_sources[fk_col]
                            # New copy_from_fk signature: (parent_table, fk_col, parent_attr)
                            c["data"] = f'copy_from_fk("{parent_table}","{fk_col}","{attr}")'
 
        compiled_commands = {}
        for column in columns:
            command = column["data"]
            column_name = column["column_name"]
            
            # Handle 'auto' that wasn't resolved by inference
            if command == "auto":
                raise RuntimeError(f"Column '{column_name}' has data='auto' but could not be automatically inferred. "
                                   f"Ensure infer_entity_attrs_by_name is enabled and the column follows naming conventions.")
            
            if command and isinstance(command, str) and "return " in command:
                func_inner_code = "\n".join(["    " + line for line in command.split("\n")])
                func_name = f"func_" + ''.join(random.choices(string.ascii_lowercase, k=5))
                func_code = f"def {func_name}():\n{func_inner_code}"
                namespace = {}
                exec(func_code, variables, namespace)
                func = namespace[func_name]
                variables[func_name] = func
                command = f"{func_name}()"
            
            compiled_commands[column_name] = compile(f"result = {command}", "<string>", "exec")


        rows = []
        pk_cols = [c["column_name"] for c in columns if c.get("is_primary_key")]
        
        # Initialize generated_rows for this table
        self.generated_rows[table_name] = rows
        
        # Track current child table for is_unique foreign key support
        self._current_child_table = table_name
        
        for row_id in range(start_row_id, start_row_id+row_count):
            util.progress_bar(row_id-start_row_id+1, row_count, f"Table:{table_name}")
            variables["row_id"] = row_id
            self.primary_key_seed = row_id
            new_row = self.generate_fake_row(table_name, columns, variables, compiled_commands)
            rows.append(new_row)
            # Cache full parent row indexed by all PK columns
            if pk_cols:
                self.parent_rows.setdefault(table_name, {})
                for pk_col in pk_cols:
                    self.parent_rows[table_name][new_row[pk_col]] = new_row

        df = pd.DataFrame(rows)
        df = df.convert_dtypes()  # auto set best fitting type
        df.Name = table['table_name']
        for column in columns:
            column_name = column['column_name']
            if "type" in column:
                util.log(f"Converting Column {column_name} to {column['type']}", util.FOREGROUND_COLOR.MAGENTA)
                df[column_name] = df[column_name].astype(column['type'])
            if "null_percentage" in column:
                null_percentage = util.parse_null_percentage(column["null_percentage"])
                num_nulls = int(row_count * null_percentage)
                null_indices = np.random.choice(df.index, size=num_nulls, replace=False)
                df.loc[null_indices, column_name] = None

        parquet_schema_map = {col['column_name']: col['parquet_type'] for col in columns if 'parquet_type' in col}
        if parquet_schema_map:
            df.attrs['parquet_schema'] = parquet_schema_map

        util.log(f"{table_name} pandas dataframe created", util.FOREGROUND_COLOR.GREEN)
        return df

    def foreign_key(self, table_name, column_name, distribution="uniform",
                    param=None, parent_attr=None, weights=None, is_unique=False):
        """
        Select a foreign key value with configurable distribution.
        
        Args:
            table_name: Parent table name
            column_name: Parent column name (must be a primary key)
            distribution: "uniform" (default), "zipf", or "weighted_parent"
            param: Parameter for zipf distribution (default 1.2)
            parent_attr: Parent attribute for weighted_parent distribution
            weights: Weight mapping for weighted_parent distribution
            is_unique: If True, each parent key is used at most once per child table
        """
        if table_name not in self.primary_key_cache:
            raise Exception(f"Table {table_name} not found while looking for primary key")
        if column_name not in self.primary_key_cache[table_name]:
            raise Exception(f"Column {column_name} not found in table {table_name} while looking for primary key")
        
        pk_values = self.primary_key_cache[table_name][column_name]
        
        # Filter out already-used values when is_unique is enabled
        if is_unique:
            unique_key = (self._current_child_table, table_name, column_name)
            used = self.unique_fk_used.setdefault(unique_key, set())
            pk_values = [v for v in pk_values if v not in used]
            if len(pk_values) == 0:
                raise Exception(
                    f"All primary key values in {table_name}.{column_name} have been used. "
                    f"Child table has more rows than available unique parent keys."
                )
        
        n = len(pk_values)
        if n == 0:
            raise Exception(f"No keys in {table_name}.{column_name}")
        
        # Create independent RNG per FK call for determinism
        seed = self._stable_seed(self.primary_key_seed, table_name, column_name, distribution, param, parent_attr, is_unique)
        rnd = random.Random(seed)
        
        if distribution == "uniform":
            idx = rnd.randrange(n)
            selected = pk_values[idx]
        elif distribution == "zipf":
            a = float(param) if param is not None else 1.2
            # weights proportional to 1/(i+1)^a over existing order
            w = [1.0 / ((i + 1) ** a) for i in range(n)]
            total = sum(w)
            r = rnd.random() * total
            cum = 0.0
            selected = pk_values[-1]
            for i, wi in enumerate(w):
                cum += wi
                if r <= cum:
                    selected = pk_values[i]
                    break
        elif distribution == "weighted_parent":
            if parent_attr is None or weights is None:
                raise Exception("weighted_parent requires parent_attr and weights")
            parent_map = self.parent_rows.get(table_name, {})
            # map index -> weight via parent attribute
            mapped = []
            for i, pk in enumerate(pk_values):
                row = parent_map.get(pk)
                val = None if row is None else row.get(parent_attr)
                mapped.append(float(weights.get(str(val), 1.0)))
            total = sum(mapped)
            r = rnd.random() * total
            cum = 0.0
            selected = pk_values[-1]
            for i, wi in enumerate(mapped):
                cum += wi
                if r <= cum:
                    selected = pk_values[i]
                    break
        else:
            raise Exception(f"Unknown distribution {distribution}")
        
        # Track used value for is_unique
        if is_unique:
            used.add(selected)
        
        return selected

    def generate_fake_row(self, table_name:str, columns:dict, variables:dict, compiled_commands:dict=None):
        """
        Generate a fake row using two-phase evaluation.
        Phase A: PK columns and foreign_key columns
        Phase B: remaining columns (including copy_from_fk)
        """
        result = {}
        
        def _exec_col(col):
            """Execute a single column's data expression."""
            column_name = col["column_name"]
            code = compiled_commands[column_name]
            command = col["data"]
            variables["command"] = command
            is_primary_key = col.get("is_primary_key", False)
            
            try:
                exec(code, variables)
            except AttributeError as error:
                raise RuntimeError(f"Attribute can not be found. {command} \n {error}")
            except NameError as error:
                raise RuntimeError(f"Function can not be found. {command} \n {error}")
            except Exception as error:
                raise error
            
            generated_value = variables["result"]
            variables[column_name] = generated_value
            result[column_name] = generated_value
            
            if is_primary_key:
                if table_name not in self.primary_key_cache:
                    self.primary_key_cache[table_name] = {}
                if column_name not in self.primary_key_cache[table_name]:
                    self.primary_key_cache[table_name][column_name] = []
                self.primary_key_cache[table_name][column_name].append(generated_value)
        
        # Phase A: PK columns without dependencies and columns with foreign_key
        # Phase B: columns that depend on other columns (including PKs with dependencies)
        phase_a = []
        phase_b = []
        col_names = {c["column_name"] for c in columns}
        
        for col in columns:
            expr = str(col["data"])
            has_fk = "foreign_key(" in expr
            is_pk = col.get("is_primary_key", False)
            
            # Check if expression references other column names
            has_dependencies = False
            if not has_fk and expr:
                # Check if any column name appears in the expression
                for col_name in col_names:
                    if col_name != col["column_name"] and col_name in expr:
                        has_dependencies = True
                        break
            
            # Phase A: independent PKs, foreign keys, and expressions with no column dependencies
            # Phase B: expressions that reference other columns
            if (is_pk or has_fk or not has_dependencies):
                phase_a.append(col)
            else:
                phase_b.append(col)
        
        for col in phase_a:
            _exec_col(col)
        
        # Make current row visible to copy_from_fk during phase B
        self._current_row = result
        try:
            for col in phase_b:
                _exec_col(col)
        finally:
            self._current_row = None
        
        return result


def to_pandas(config_source:str, table_name=None, **kwargs):
    table_faker = TableFaker()
    return table_faker.to_pandas(config_source, table_name, **kwargs)

def to_csv(config_source, target_file_path=None, table_name=None, **kwargs) :
    table_faker = TableFaker()
    return table_faker.to_target("csv", config_source, target_file_path, table_name, **kwargs)

def to_json(config_source, target_file_path=None, table_name=None, **kwargs) :
    table_faker = TableFaker()
    return table_faker.to_target("json", config_source, target_file_path, table_name, **kwargs)

def to_excel(config_source, target_file_path=None, table_name=None, **kwargs) :
    table_faker = TableFaker()
    return table_faker.to_target("excel", config_source, target_file_path, table_name, **kwargs)

def to_parquet(config_source, target_file_path=None, table_name=None, **kwargs) :
    table_faker = TableFaker()
    return table_faker.to_target("parquet", config_source, target_file_path, table_name, **kwargs)

def to_deltalake(config_source, target_file_path=None, table_name=None, **kwargs) :
    table_faker = TableFaker()
    return table_faker.to_target("deltalake", config_source, target_file_path, table_name, **kwargs)

def to_sql(config_source, target_file_path=None, table_name=None, **kwargs) :
    table_faker = TableFaker()
    return table_faker.to_target("sql", config_source, target_file_path, table_name, **kwargs)

def to_target(file_type, config_source, target_file_path, table_name=None, **kwargs) :
    table_faker = TableFaker()
    return table_faker.to_target(file_type, config_source, target_file_path, table_name, **kwargs)

def yaml_to_json(config_source, target_file_path=None):
    conf = config.Config(config_source)
    conf.to_json(target_file_path)

def avro_to_yaml(avro_file_path, target_file_path=None):
    config.Config.avro_to_yaml(avro_file_path, target_file_path)

def csv_to_yaml(csv_file_path, target_file_path=None):
    config.Config.csv_to_yaml(csv_file_path, target_file_path)